//#6



var express = require('express');
var app = express(); //최초 경로를 만들기 위해
app.use(express.json()); // json을 서버에서 받을 수 있게 설정.
app.use(express.urlencoded({ extended: false })); //한글 인코딩이 안깨지도록.
var router = express.Router();


//send를 보내면 EndPoint로 본다.
// 실제로는 라우터들을 뽑아내어서 하나의 파일로 만들어 사용한다.
// 모조건 이 아이를 거치고 간다.
app.use('/tiger',require('./routes/tiger'));//
//require은 마치 파일 import해서 변수에 넣고 대입하듯이 가능하네.




 var port = process.env.PORT || '5000';
 app.listen(port, ()=>{ console.log('listen');}); 

 module.exports = app;



//==============
// //#4

// var express = require('express');
// var app = express();
// app.use(express.json()); // json을 서버에서 받을 수 있게 설정.
// app.use(express.urlencoded({ extended: false })); //한글 인코딩이 안깨지도록.
// var router = express.Router();


// //send를 보내면 EndPoint로 본다.
// // 실제로는 라우터들을 뽑아내어서 하나의 파일로 만들어 사용한다.
// app.use('/tiger',
//     router.get('/',
//     function(req, res, next){
//         if(req.query.value == 1){ //query 같은 경우는 파라미터를 받을 때 사용하는 것이다.
//             console.log(1111);
//             next('route');//route일 경우 다음 라우터로 점프 해버린다.
//         }
//         else{
//             console.log(2222);
//             next();
//         }
// },
//     function(req, res, next){
//         console.log(3333);
//         res.send('앵무새1')
// }
// ),
// router.get('/',function(req,res,next){
//     console.log(4444);
//     res.send('다음 라우터')
// })
// );


//  var port = process.env.PORT || '5000';
//  app.listen(port, ()=>{ console.log('listen');}); 

//  module.exports = app;


//=============
//#3

// var express = require('express');
// var app = express();


// app.use(express.json()); // json을 서버에서 받을 수 있게 설정.
// app.use(express.urlencoded({ extended: false })); //한글 인코딩이 안깨지도록.




// var router = express.Router();


// //send를 보내면 EndPoint로 본다.

// app.use('/tiger',
//     router.get('/',(req, res, next)=>{
//     console.log('1');
//     res.send('앵무새1');
// }),
// router.get('/lion',(req, res, next)=>{
//     console.log('1');
//     res.send('앵무새2');
// })

// );


//  var port = process.env.PORT || '5000';
//  app.listen(port, ()=>{ console.log('listen');}); 

//  module.exports = app;



//===============================

// //#2

// var express = require('express');
// var app = express();


// app.use(express.json()); // json을 서버에서 받을 수 있게 설정.
// app.use(express.urlencoded({ extended: false })); //한글 인코딩이 안깨지도록.



// //send를 보내면 EndPoint로 본다.
// app.use('/tiger',function(req,res,next){
//     if(req.query.value==1){
//         next(); //다음 함수가서 send 찾아봐라
//     }
//     else{
//         console.log('tiger');
//         res.send('호랑이');
//     }
//     console.log(1);
//     // res.send('호랑이1');
    

// },
// function(req,res,next){
//     console.log(2);
//     //res.send('호랑이2');
//     next(); //다음 함수가서 send 찾아봐라
// },
// function(req,res,next){
//     console.log(3);
//     res.send('호랑이3');
   
// }
// )

//  var port = process.env.PORT || '5000';
//  app.listen(port, ()=>{ console.log('listen');}); 

//  module.exports = app;
//==============================

//#1
// var express = require('express');
// var app = express();


// app.use(express.json()); // json을 서버에서 받을 수 있게 설정.
// app.use(express.urlencoded({ extended: false })); //한글 인코딩이 안깨지도록.


// // //1차 경로. localhost:5000/users라고 입력하면 들어감
// // app.use( '/users', require('./routes/users') );

// // //위와 같다.
// // // let a = require('./routes/users') 
// // // app.use( '/users',a);


// // //직접 받을 수 있다/..use==뭐든지 다 발을 수 있다.
// // app.use( '/api/swtool', require('./routes/SwtoolRout') );


// //같은 주소라도 먼저 입력한 놈이 나온다. use는 get, post 둘다 된다?
// app.use('/',function(req,res,next){
//     console.log(1);
//     res.send('호랑이');

// })

// app.get('/',function(req,res,next){
//     console.log(1);
//     res.send('호랑이');

// })


// app.post('/',function(req,res,next){
//     console.log(1);
//     res.send('호랑이');

// })

// app.use('/lion', function(req, res, next){
// console.log('use');
// res.send('호랑이');
//     }    );


//  var port = process.env.PORT || '5000';
//  app.listen(port, ()=>{ console.log('listen');}); 

//  module.exports = app;